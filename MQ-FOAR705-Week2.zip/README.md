# Week 1 slides for FOAR 705 at Macquarie University. 2019.

License: CC-BY 4.0 International. Shawn Ross, Brian Ballsun-Stanton, Macquarie University

LaTeX template:

A Beamer Theme for Macquarie University

Forked from [Metropolis](https://github.com/matze/mtheme)

Edits by:

* Brian Ballsun-Stanton (@denubisx)
* James Tocknell (@aragilar)

Compile with:

~~~
$ xelatex main && bibtex main.aux && xelatex main
~~~
